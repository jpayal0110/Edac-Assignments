package newpackage;

class Node1
{
    int data;
    Node1 flink;
    Node1 blink;
    
    Node1(int data){
        this.data = data;
        this.flink = this.blink = null;
        
    }   
}
    class DoubleLinklist {
        private Node1 start;
        private int length;
        
        DoubleLinklist(){
            this.start = null;
            this.length = 0;
        }
        //=====================================================
        public void insertBeg(int data)
        {
            Node1 newNode = new Node1(data);
            
            if(start == null)
            {
                start =  newNode;
            }
            else
            {
                start.blink = newNode;
                newNode.flink = start;
                start = newNode;
            }
            length++;
        }


        public void insertPos(int data, int pos)
        {
            if(pos == 1)
            {
                insertBeg(data);
            }
            else if(pos> length)
            {
                insertEnd(data);
            }
            else
            {
                int i=1;
                Node1 n = start;
                
                while(n.flink !=null)
                {
                    i++;
                    if(i == pos)
                        break;
                    n = n.flink;
                }
                Node1 newNode = new Node1(data);
                newNode.blink = n;
                newNode.flink = n.flink;
                n.flink.blink = newNode;
                n.flink = newNode;
                length++;
            }  
        }
        
         public void insertEnd(int data)
        {
            Node1 newNode = new Node1(data);
            
            if(start == null)
            {
                start =  newNode;
            }
            else
            {
                Node1 n =start;
                while(n.flink != null)
                {
                    n = n.flink;                 
                }
                n.flink = newNode;
                newNode.blink = n ;
            }           
            length++;
        }
        
        //==========================================================
        public void deleteBeg()
        {
            Node1 n = start;
            if(start == null)
            {
                System.out.println("Empty list");
            }
            else
            {
                start =  n.flink;
                start.blink = null;
            }
            length--;
        }
        
        public void deleteEnd()
        {
            if(start == null)
            {
                System.out.println("empty list");
            }
            else
            {
                Node1 n =start;
                
                while(n.flink.flink != null)
                {
                    n = n.flink;
                }
                n.flink.blink = null;
                n.flink = null;
                length--;
            }
        }
        public void deletePos(int pos)
        {
            if(pos <0)
            {
                System.out.println("empty list");
            }
            if(pos == 1)
            {
                deleteBeg();
            }
            else if(pos > length)
            {
                deleteEnd();
            }
            
            else
            {
                int i =1;
                Node1 p =start;
                
                while(p.flink != null)
                {
                    i++;
                    if(i== pos)
                    {
                        break;
                    }
                    p = p.flink; 
                }
                p.flink.flink.blink = p;
                p.flink = p.flink.flink;
                length--;
            }  
        }
        //=====================================================
        
        public void displayForward()
        {
            Node1 n =start;
            while(n.flink !=null)
            {
                System.out.print(n.data + "->");
                n = n.flink;
            }
            System.out.println(n.data + " ");
        }
        
         public void displayBackward()
        {
             Node1 n =start;
             while(n.flink != null)
             {
                 n = n.flink;
             }
             while(n.blink !=null)
             {
                 System.out.println(n.data + " ");
                 n = n.blink;
             }
             System.out.println(n.data + " ");  
        }  
    

    public static void main(String[] args)
    {
        DoubleLinklist d1 = new DoubleLinklist();
        d1.insertBeg(10);
        d1.insertBeg(20);
        d1.insertBeg(30);
        
        d1.insertEnd(50);
        
        d1.insertPos(40,3);
        d1.displayForward();
        System.out.println();
        
        d1.deleteBeg();
        d1.deleteEnd();
        d1.displayForward();
        System.out.println();
        
        d1.displayBackward();
        System.out.println();
           
    }
    
}

