
package newpackage;



class Queue1
{
   int front,tail;
   int[] q=new int[5];
   Queue1()
   {
	  front=tail=-1; 
   }
   
   void insert(int x)
   {
	   if(front==0 &&tail==q.length-1)
	   {
		  System.out.println("Queue is full"); 
	   }
	   else if(front==-1 && tail==-1)
	   {
		   front=tail=0;
		   q[tail]=x;
		   System.out.println("inserted ele"+q[tail]+"raer ind"+tail);
	   }
	   else if(tail==q.length-1 && front!=0)
	   {
		   tail=0;
		   q[tail]=x;
		   System.out.println("inserted ele"+q[tail]+"raer ind"+tail);
	   }
	   else
	   {
		   tail++;
		   q[tail]=x;
		   System.out.println("inserted ele"+q[tail]+"raer ind"+tail);

	   }
   }
   
   int delete()
   {
	   int val;
	   if(front==-1 && tail==-1)
	   {
		   System.out.println("Under flow");
		   return -1;
	   }
	   val=q[front];
	   System.out.println("deleted ele"+val+"front ind "+front);

	   if(front==tail)
	   {
		   System.out.println("front ind "+front);

		   front=tail=-1;
		   System.out.println("front ind "+front);

	   }
	   else
	   {
		   if(front==q.length)
		   {
			   front=0;
		   }
		   else
		   {
			   front++;
		   }
	   }
	   return val;
   }
 
}
public class Queue 
{
    public static void main(String[] args) 
        {
		Queue1 q=new Queue1();
		q.insert(10);
		q.insert(20);
		q.insert(30);
		//q.insert(40);
		//q.insert(50);
		//q.insert(60);
		System.out.println(q.delete());
		System.out.println(q.delete());
		System.out.println(q.delete());
		//System.out.println(q.delete());;
		//System.out.println(q.delete());;
		//System.out.println(q.delete());;
		q.insert(60);
		System.out.println(q.delete());

    }
}

   