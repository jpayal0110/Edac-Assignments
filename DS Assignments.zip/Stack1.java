package newpackage;

class Stack1 
{
    int top =0;
    int size = 0;
    int capacity = 5;
    int a[] = new int[5];
    
    boolean isEmpty()
    {
        return(top<0);
    }
    
    boolean isFull()
    {
        return(top > capacity);
    }
    
    void push(int x)
    {
        if(isFull())
        {
            System.out.println("STACK is FULL");
        }
        else
        {
            a[top++] = x;
            System.out.println(x + "is pushed inside the stack"); 
        }
        
    }
    
    public int pop( )
    {
        if(isEmpty())
        {
            System.out.println("STACK is EMPTY");
        }
        //else return a[--top]
        {
            System.out.println(a[--top]); 
        }
        return 1;
    }
    
    int peek()
    {
        if(top<0)
        {
            System.out.println("STACK UNDERFLOW");
            return 0;
        }
        else{
            int x =a[top];
            return x;
        }
    }
    
    public static void main(String[] args)
    {
        Stack1 s = new Stack1();
        s.push(10);
        s.push(20);
        s.push(30);
        s.push(40);
        s.push(50);
        //s.push(60);
	System.out.println(" "+s.pop()+" "+s.pop());
        s.peek();
    }
    
}
    
   

            
            
            
    
    
