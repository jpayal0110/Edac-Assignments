
package newpackage;
public class Circular {
    int length;
    public class Node
    {
        int data;
        Node next;
         
        Node(int data)
        {
            this.data = data;
        }
        
    }
     
    public Node head =  null;
    public Node tail = null;
     
    public void insert(int data)
    {
       Node ins = new Node(data);
        
        if(head == null)
        {
           head = ins;
           tail = ins;
        }
        else
        {
            tail.next = ins;  //tail will point to new node
            tail = ins;        //newnode is tail
            tail.next = head;   //as it is a circular linked list tail will point to head
           
        }
        length++;
    }

    
    
    public void display()
    {
        Node current = head;
        
        if(head == null)
        {
            System.out.println("EMPTY LIST");
        }
        else
        {
            System.out.println("Nodes of Circular linked list");
            
            
            do
            {
                System.out.println(" "+ current.data);
                current = current.next;
            }
            while(current != head);
                    {
                        System.out.println();
                    }
        }
    }
    
    
    public static void main(String[] args)
    {
        Circular cl = new Circular();
        
        cl.insert(10);
        //cl.insertend(20);
        cl.insert(30);
        cl.insert(40);
        cl.insert(50);
        
        cl.display();
    }
}
