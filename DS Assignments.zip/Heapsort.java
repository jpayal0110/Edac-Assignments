
package newpackage;

public class Heapsort {
    public int[] acbt;
    public int counter;
    
    public Heapsort(int N)
    {
        acbt = new int[N];
        counter =0;
    }
    
    public int get_left(int ind)
    {
        return 2*ind;
    }
    public int get_right(int ind)
    {
        return 2*ind+1;
    }
    public int get_parent(int ind)
    {
        return ind/2;
    }
    
    public void insert(int x)
    {
        acbt[++counter] = x;
        int par = get_parent(counter);
        
        for(;par>0;)
        {
            if(acbt[par]>x)
            {
                int t = x;
                x = acbt[par];
                acbt[par] = t;
                par= get_parent(par);
            }
            else break;
        }
        
    }
    
    public void print_acbt()
    {
        for(int i=1; i<=counter; i++)
            System.out.print(" "+acbt[i]);
    }
    public static void main(String[] args)
    {
        int[] list = {10,22,34,44,45,65,2,4};
        
        Heapsort h =new Heapsort(list.length);
        for(int i=0; i<list.length; i++)
        {
            h.insert(list[i]);
            System.out.println();
        }
    }
}
