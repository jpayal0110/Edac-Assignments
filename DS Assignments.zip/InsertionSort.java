
package newpackage;

class InsertionSort
{
    public static void insertionsort(int a[])
    {
        int n = a.length;
        for(int j = 0; j<a.length; j++ )
        {
            int key =a[j];
            int  i = j-1;
            while((i>-1) && (a[i])>key )
            {
                a[i+1] = a[i];
                i--;
            }
            a[i+1] =key;
        }
    }
    
public static void main(String[] args)
{
    int[] a1 = {9,8,5,3,14,35,66};
    System.out.println("BEfore insertion sort");
    
    for(int i: a1)
    {
        System.out.println(i+" ");
    }
    System.out.println();
    
    insertionsort(a1);
    System.out.println("AFter insertion sort");
    
    for(int i: a1)
    {
        System.out.println(i+" ");
    }
}
}
                
            
        
        
            
          
   
   