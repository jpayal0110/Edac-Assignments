package newpackage;
import java.util.Arrays;


class MergeSort 
{
    //a->array, p->head, q-> mid, r-> tail
    void merge(int a[], int p, int q, int r)
    {
        int n1 = q-p+1; //size of arrays
        int n2 = r - q;
        
        int L[] = new int[n1]; //initializing array
        int M[] = new int[n2];
        
        //fill left and right array
        for(int i= 0 ; i<n1; i++)
            L[i] = a[p+i];
        for(int j=0; j<n2; j++)
            M[j] = a[q+1+j];
   
        int i, j, k;
        i = 0;
        j = 0;
        k = p;
        while(i<n1 && j<n2)
        {
                if(L[i] <= M[j])
                {
                    a[k] = L[i];
                    i++;
                }
                else
                {
                    a[k] = M[j];
                    j++;
                }
                k++;
        }
            while(i<n1)
            {
                a[k++] = L[i++];
            }
            while(j<n2)
            {
                a[k++] = M[j++];
            }
        }
    
        
    void mergesort(int a[], int left , int right)
   {
    if (left < right) 
    {
        int mid = (left + right) / 2;   // m is the point where the array is divided into two sub arrays
        
        mergesort(a, left, mid);        // recursive call to each sub arrays
        mergesort(a, mid + 1, right);   // recursive call to each sub arrays
       
        merge(a, left, mid, right);// Merge the sorted sub arrays  
    }
  }

  public static void main(String args[]) {

    // created an unsorted array
    
    int[] array = { 6, 5, 12, 10, 9, 1 };
    System.out.println("Unsorted Array:\n" +(Arrays.toString(array)));
    
    MergeSort ob = new MergeSort();

    // call the method mergeSort()
    // pass argument: array, first index and last index
    ob.mergesort(array, 0, array.length - 1);

    
    System.out.println("Sorted Array:");
    System.out.println(Arrays.toString(array));
  }
    
}
