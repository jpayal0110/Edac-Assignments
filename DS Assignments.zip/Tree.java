package newpackage;


class Node {
    int key ;
    Node left, right;
    
    public Node(int item)
    {
        key = item; //key=data
        left=right = null;
    }
}

class BinaryTree
{
    Node root;       //root of binary tree
    
    BinaryTree()
    {
        root = null;
    }
    
    void printPreorder(Node node) //middle left right
    {
        if(node ==null)
            return;
        System.out.println(node.key + " ");
        printPreorder(node.left);
        printPreorder(node.right);   
    }
    void printPostorder(Node node) //left right middle
    {
        if(node ==null)
            return;
        printPostorder(node.left);
        printPostorder(node.right);
        System.out.println(node.key +" ");
    }
    void printInorder(Node node) //lft middle right
    {
        if(node ==null)
            return;
        printInorder(node.left);
        System.out.println(node.key +" ");
        printInorder(node.right);   
    }
    
    //wrappers over above recursive functions
    void printPreorder()
    {
        printPreorder(root);
    }
    
    void printPostorder()
    {
        printPostorder(root);
    }
    
    void printInorder()
    {
        printInorder(root);
    }
    
    public static void main(String[] args)
    {
        BinaryTree tree = new BinaryTree();
        tree.root = new Node(1);
        tree.root.left = new Node(2);
        tree.root.right = new Node(3);
        tree.root.left.left = new Node(4);
        tree.root.left.right = new Node(5);
        
        System.out.println("Preorder traversal of binary tree is "); 
        tree.printPreorder(); 
        
        System.out.println("Postorder traversal of binary tree is "); 
        tree.printPostorder(); 
        
        System.out.println("Inorder traversal of binary tree is "); 
        tree.printInorder();  
        
    }
            
}