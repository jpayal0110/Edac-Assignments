package newpackage;
class Array
{
    private long arr[];
    private int n =0;
    
    
    public Array(int maxsize)
    {
        
        arr = new long[maxsize];
        n=0;
    }
    
    public boolean search(long searchvalue)
    {
        int j;
        for(j=0;j<n;j++)
       
            if(arr[j]== searchvalue)
            
                break;
            
        if(j == n)
        {
            return false;
            //System.out.println(searchvalue+ "Not Found");
        }
        else
            return true;
            //System.out.println(searchvalue+ "Found");
    }
    
    
    //=======================================================
    public void insert(long value)
    {
        arr[n]= value;
        n++;
    }
    
    //===========================================================
    public boolean delete(long value)
        {
             for(int j = 0; j<n;j++)
            {
                if(arr[j] == value)
                    break;
                if(j==n)
                    return false;
                else
                
                for(int k=j; k<n-1; k++)
                {
                    arr[k] =arr[k+1];
                }   
            }
            n--;
            return true;
        }
   
    //==========================================================
   
    
     public void display()
        {
            for(int j=0; j<n; j++)
            {
            System.out.print(arr[j]+" ");
            }     
        }
}
//============================================
public class ArrayTest1 
{
    public static void main(String[] args)
    {
        int maxsize =100;
        Array arr;
        arr =  new Array(maxsize);
        
        arr.insert(77);
        arr.insert(99);
        arr.insert(74);
        arr.insert(55);
        arr.insert(22);
        arr.insert(44);
        arr.insert(55);
        arr.insert(45);
        arr.insert(76);
        arr.insert(46);
        
        arr.display();
        
        int searchvalue = 45;
        if(arr.search(searchvalue))
            System.out.println("Found " + searchvalue);
        else
            System.out.println("Cannot Found " + searchvalue);
        
        arr.delete(74);
        arr.delete(44);
        
        arr.display();
    }
    
    
}
